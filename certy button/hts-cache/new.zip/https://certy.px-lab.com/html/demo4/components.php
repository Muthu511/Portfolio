<!DOCTYPE html>
<html lang="en" class="crt crt-nav-on crt-nav-type1 crt-main-nav-on crt-sidebar-on crt-layers-2">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Certy</title>
    <meta name="description" content="">

    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,700" rel="stylesheet">

    <!-- Icon Fonts -->
    <link href="assets/fonts/icomoon/style.css" rel="stylesheet">

    <!-- Styles -->
    <link href="assets/css/plugins.min.css" rel="stylesheet">
    <link href="assets/css/style.min.css" rel="stylesheet">

    <!-- Modernizer -->
    <script type="text/javascript" src="assets/js/vendor/modernizr-3.3.1.min.js"></script>
	
	<!-- Google Analytics -->
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-92973565-1', 'auto');
	  ga('send', 'pageview');
	</script>
  </head>

  <body class="">
     <div class="crt-wrapper">
         <header id="crt-header">
             <div class="crt-head-inner crt-container">
                 <div class="crt-container-sm">
                     <div class="crt-head-row">
                         <div id="crt-head-col1" class="crt-head-col text-left">
                             <a id="crt-logo" class="crt-logo" href="index.php">
                                 <img src="assets/images/uploads/brand/logo.svg" alt="certy resume"><span>.Certy</span>
                             </a>
                         </div>

                                                  <div id="crt-head-col2" class="crt-head-col text-right">
                             <div class="crt-nav-container crt-container hidden-sm hidden-xs">
                                 <nav id="crt-main-nav">
                                    
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>                                 </nav>
                             </div>
                         </div>
                         
                                                  <div id="crt-head-col3" class="crt-head-col text-right">
                             <button id="crt-sidebar-btn" class="btn btn-icon btn-shade">
                                 <span class="crt-icon crt-icon-side-bar-icon"></span>
                             </button>
                         </div>
                                              </div>
                 </div><!-- .crt-head-inner -->
             </div>

                              <nav id="crt-nav-sm" class="crt-nav hidden-lg hidden-md">
                         <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                 </nav><!-- #crt-nav-sm -->
                     </header><!-- #crt-header -->

        <div id="crt-container" class="crt-container">
            
                            <div id="crt-nav-wrap" class="hidden-sm hidden-xs">
                    <div id="crt-nav-inner">
                        <div class="crt-nav-cont">
                            <div id="crt-nav-scroll">
                                <nav id="crt-nav" class="crt-nav">
                                        <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                                </nav>
                            </div>

                            <div id="crt-nav-tools" class="hidden">
                                <span class="crt-icon crt-icon-dots-three-horizontal"></span>

                                <button id="crt-nav-arrow" class="clear-btn">
                                    <span class="crt-icon crt-icon-chevron-thin-down"></span>
                                </button>
                            </div>
                        </div>
                        <div class="crt-nav-btm"></div>
                    </div>
                </div><!-- .crt-nav-wrap -->
            
            <div class="crt-container-sm"><div class="crt-paper-layers">
    <div class="crt-paper clearfix">
        <div class="crt-paper-cont paper-padd clear-mrg">

    <div class="padd-box">
        <h1 class="title-lg text-upper">Component Page</h1>


        <!-- LINE TYPES -->
        <h2 class="text-upper">Line types</h2>

        <div class="padd-box-sm">
            <hr>
            <hr class="dotted">
            <hr class="dashed">
            <hr class="brd-primary">
            <hr class="dotted brd-primary">
            <hr class="dashed brd-primary">

            <p class="text-right"><a class="toggle-link" href="#code-lines"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-lines" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;hr&gt;
&lt;hr class="dotted"&gt;
&lt;hr class="dashed"&gt;
&lt;hr class="brd-primary"&gt;
&lt;hr class="dotted brd-primary"&gt;
&lt;hr class="dashed brd-primary"&gt;</code></pre>
        </div><!-- .toggle-cont -->


        <!-- ALERTS -->
        <h2 class="text-upper">Alerts</h2>

        <div class="padd-box-sm">
            <div class="alert alert-success" role="alert">
                <strong>Well done!</strong> You successfully read this important alert message
                <button type="button" class="close"><span class="crt-icon crt-icon-close"></span></button>
            </div>

            <div class="alert alert-info" role="alert">
                <strong>Heads up!</strong> This alert needs your attention, but it's not super important.
                <button type="button" class="close"><span class="crt-icon crt-icon-close"></span></button>
            </div>

            <div class="alert alert-warning" role="alert">
                <strong>Warning!</strong> Better check yourself, you're not looking too good.
                <button type="button" class="close"><span class="crt-icon crt-icon-close"></span></button>
            </div>

            <div class="alert alert-danger" role="alert"><strong>Oh snap!</strong> Change a few things up and try submitting again.
                <button type="button" class="close"><span class="crt-icon crt-icon-close"></span></button>
            </div>

            <p class="text-right"><a class="toggle-link" href="#code-alerts"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-alerts" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;div class="alert alert-success" role="alert"&gt;
    &lt;strong&gt;Heads up!&lt;/strong&gt; You successfully ...
&lt;/div&gt;

&lt;div class="alert alert-info" role="alert"&gt;
    &lt;strong&gt;Well done!&lt;/strong&gt; This alert ...
&lt;/div&gt;

&lt;div class="alert alert-warning" role="alert"&gt;
    &lt;strong&gt;Warning!&lt;/strong&gt; Better check ...
&lt;/div&gt;

&lt;div class="alert alert-danger" role="alert"&gt;
    &lt;strong&gt;Oh snap!&lt;/strong&gt; Change a few ...
&lt;/div&gt;</code></pre>
        </div><!-- .toggle-cont -->


        <!-- BUTTONS -->
        <h2 class="text-upper">Buttons</h2>

        <div class="padd-box-sm">
            <p class="btn-group">
                <a class="btn btn-primary" href="#" role="button">Link</a>
                <button class="btn btn-primary" type="submit">Button</button>
                <input class="btn btn-primary" type="button" value="Input">
                <input class="btn btn-primary" type="submit" value="Submit">
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-tags"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-tags" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use the button classes on an &lt;a&gt, &lt;button&gt, or &lt;input&gt element --&gt;
&lt;a class="btn btn-primary" href="#" role="button"&gt;Link&lt;/a&gt;
&lt;button class="btn btn-primary" type="submit"&gt;Button&lt;/button&gt;
&lt;input class="btn btn-primary" type="button" value="Input"&gt;
&lt;input class="btn btn-primary" type="submit" value="Submit"&gt;

&lt;!-- Use &lt;div&gt;, &lt;p&gt; or &lt;span&gt; wrapper with the .btn-group class if you have more than one button --&gt;
&lt;div class="btn-group"&gt;
    &lt;button class="btn btn-primary"&gt;Button&lt;/button&gt;
    &lt;button class="btn btn-primary"&gt;Button&lt;/button&gt;
    ...
&lt;/div&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Sizes</h3>

            <p class="btn-group">
                <button class="btn btn-primary btn-lg">Large Button</button>
                <button class="btn btn-primary">Normal Button</button>
                <button class="btn btn-primary btn-sm">Small Button</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-sizes"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-sizes" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use .btn-lg or .btn-sm classes for larger or smaller buttons. --&gt;
&lt;button class="btn btn-primary btn-lg"&gt;Large Button&lt;/button&gt;
&lt;button class="btn btn-primary"&gt;Normal Button&lt;/button&gt;
&lt;button class="btn btn-primary btn-sm"&gt;Small Button&lt;/button&gt;</code></pre>
       </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <p><button class="btn btn-primary btn-block btn-lg">Block Level Button</button></p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-block"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-block" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use .btn-block class to create button that span the full width of a parent --&gt;
&lt;button class="btn btn-primary btn-block"&gt;Large Button&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Colors</h3>

            <p class="btn-group">
                <button class="btn btn-default">Default</button>
                <button class="btn btn-primary">Primary</button>
                <button class="btn btn-light">Light</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-color"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-color" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use .btn-default .btn-primary or .btn-light classes for button coloring --&gt;
&lt;button class="btn btn-default"&gt;Default&lt;/button&gt;
&lt;button class="btn btn-primary"&gt;Primary&lt;/button&gt;
&lt;button class="btn btn-light"&gt;Light&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Thin</h3>

            <p class="btn-group">
                <button class="btn btn-thin btn-default">Default</button>
                <button class="btn btn-thin btn-primary ">Primary</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-thin"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-thin" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use .btn-thin class for button light text --&gt;
&lt;button class="btn btn-thin btn-default"&gt;Default&lt;/button&gt;
&lt;button class="btn btn-thin btn-primary"&gt;Primary&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Uppercase</h3>

            <p class="btn-group">
                <button class="btn btn-upper btn-default ">Default</button>
                <button class="btn btn-upper btn-primary ">Primary</button>
                <button class="btn btn-thin btn-upper btn-default">Default</button>
                <button class="btn btn-thin btn-upper btn-primary ">Primary</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-upper"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-upper" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Use .btn-upper class for transforming button text --&gt;
&lt;button class="btn btn-upper btn-default"&gt;Default&lt;/button&gt;
&lt;button class="btn btn-upper btn-primary"&gt;Primary&lt;/button&gt;

&lt;button class="btn btn-upper btn-thin btn-default"&gt;Default&lt;/button&gt;
&lt;button class="btn btn-upper btn-thin btn-primary"&gt;Primary&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Disabled</h3>

            <p class="btn-group">
                <button type="button" class="btn btn-lg btn-primary" disabled="disabled">Disabled</button>
                <button type="button" class="btn btn-default btn-lg" disabled="disabled">Disabled</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-disabled"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-disabled" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Add the "disabled" attribute to buttons --&gt;
&lt;button class="btn btn-default" disabled="disabled"&gt;Disabled&lt;/button&gt;
&lt;button class="btn btn-primary" disabled="disabled"&gt;Disabled&lt;/button&gt;

&lt;!-- Add .disabled class for just styling --&gt;
&lt;a class="btn btn-default disabled" href="#" role="button"&gt;Disabled&lt;/a&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>With Icons</h3>

            <p class="btn-group">
                <button class="btn btn-primary btn-lg"><span class="crt-icon crt-icon-location-arrow"></span>Large Button</button>
                <button class="btn btn-primary"><span class="crt-icon crt-icon-location-arrow"></span>Normal Button</button>
                <button class="btn btn-primary btn-sm"><span class="crt-icon crt-icon-location-arrow"></span>Small Button</button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-icons"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-icons" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;button class="btn btn-primary btn-lg"&gt;
    &lt;span class="crt-icon crt-icon-location-arrow"&gt;&lt;/span&gt;Large Button
&lt;/button&gt;

&lt;button class="btn btn-primary"&gt;
    &lt;span class="crt-icon crt-icon-location-arrow"&gt;&lt;/span&gt;Normal Button
&lt;/button&gt;

&lt;button class="btn btn-primary btn-sm"&gt;
    &lt;span class="crt-icon crt-icon-location-arrow"&gt;&lt;/span&gt;Small Button
&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <h3>Circle Buttons</h3>

            <p class="btn-group">
                <button class="btn btn-icon btn-light"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
                <button class="btn btn-icon btn-light btn-shade"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
                <br>
                <button class="btn btn-icon btn-primary"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
                <button class="btn btn-icon btn-primary btn-shade"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
                <br>
                <button class="btn btn-icon btn-default"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
                <button class="btn btn-icon btn-default btn-shade"><span class="crt-icon crt-icon-side-bar-icon"></span></button>
            </p>

            <p class="text-right"><a class="toggle-link" href="#code-btn-circle"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-btn-circle" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;button class="btn btn-icon btn-light"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;
&lt;button class="btn btn-icon btn-light btn-shade"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;

&lt;button class="btn btn-icon btn-primary"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;
&lt;button class="btn btn-icon btn-primary btn-shade"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;

&lt;button class="btn btn-icon btn-default"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;
&lt;button class="btn btn-icon btn-default btn-shade"&gt;
    &lt;span class="crt-icon crt-icon-side-bar-icon"&gt;&lt;/span&gt;
&lt;/button&gt;</code></pre>
        </div><!-- .toggle-cont -->


        <!-- PROGRESS BARS -->
        <h2 class="text-upper">Progress Bars</h2>

        <div class="padd-box-sm">
            <div class="row">
                <div class="col-sm-5">
                    <div class="progress-chart crt-animate" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" data-text="90%" data-value="0.9"></div>
                        <strong class="progress-title">UX Design</strong>
                    </div>
                </div><!-- .col-sm-6 -->

                <div class="col-sm-7">
                    <div class="progress-bullets crt-animate" role="progressbar" aria-valuenow="7" aria-valuemin="0" aria-valuemax="10">
                        <strong class="progress-title">Italian</strong>
                        <span class="progress-bar">
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet fill"></span>
                            <span class="bullet"></span>
                            <span class="bullet"></span>
                            <span class="bullet"></span>
                        </span>
                        <span class="progress-text text-muted">begginer</span>
                    </div><!-- .progress-bullets -->

                    <div class="progress-line crt-animate" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">
                        <strong class="progress-title">Php & MySQL</strong>
                        <div class="progress-bar" data-text="90%" data-value="0.9"></div>
                    </div><!-- .progress-line -->
                </div><!-- .col-sm-6 -->
            </div><!-- .row -->

            <p class="text-right"><a class="toggle-link" href="#code-progress-bars"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-progress-bars" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Chart --&gt;
&lt;div class="progress-chart" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"&gt;
    &lt;div class="progress-bar" data-text="90%" data-value="0.9"&gt;&lt;/div&gt;
    &lt;strong class="progress-title"&gt;UX Design&lt;/strong&gt;
&lt;/div&gt;

&lt;!-- Bullet Progress Bar --&gt;
&lt;div class="progress-bullets" role="progressbar" aria-valuenow="7" aria-valuemin="0" aria-valuemax="10"&gt;
    &lt;strong class="progress-title"&gt;Italian&lt;/strong&gt;
    &lt;span class="progress-bar"&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet fill"&gt;&lt;/span&gt;
        &lt;span class="bullet"&gt;&lt;/span&gt;
        &lt;span class="bullet"&gt;&lt;/span&gt;
        &lt;span class="bullet"&gt;&lt;/span&gt;
    &lt;/span&gt;
    &lt;span class="progress-text text-muted"&gt;begginer&lt;/span&gt;
&lt;/div&gt;

&lt;!-- Line Progress Bar --&gt;
&lt;div class="progress-line" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"&gt;
    &lt;strong class="progress-title"&gt;Php & MySQL&lt;/strong&gt;
    &lt;div class="progress-bar" data-text="90%" data-value="0.9"&gt;&lt;/div&gt;
&lt;/div&gt;</code></pre>
        </div><!-- .toggle-cont -->


        <!-- TABS -->
        <h2 class="text-upper">Tabs</h2>

        <div class="padd-box-sm">
            <div class="tabs tabs-horizontal">
                <ul class="tabs-menu">
                    <li class="active"><a href="#tab-hrz-1">Tab 1</a></li>
                    <li><a href="#tab-hrz-2">Tab 2</a></li>
                    <li><a href="#tab-hrz-3">Tab 3</a></li>
                    <li><a href="#tab-hrz-4">Tab 4</a></li>
                </ul>

                <div class="tabs-content">
                    <div id="tab-hrz-1" class="tab-content">Tab 1 content !<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>

                    <div id="tab-hrz-2" class="tab-content">Tab 2 content !<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>

                    <div id="tab-hrz-3" class="tab-content">Tab 3 content !<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>

                    <div id="tab-hrz-4" class="tab-content">Tab 4 content !<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </div>
            </div><!-- .tabs-horizontal -->

            <p class="text-right"><a class="toggle-link" href="#code-tabs-horizontal"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-tabs-horizontal" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Horizontal Tabs --&gt;
&lt;div class="tabs tabs-horizontal"&gt;
    &lt;ul class="tabs-menu"&gt;
        &lt;li class="active"&gt;&lt;a href="#tab-hrz-1"&gt;Tab 1&lt;/a&gt;&lt;/li&gt;
        &lt;li&gt;&lt;a href="#tab-hrz-2"&gt;Tab 2&lt;/a&gt;&lt;/li&gt;
        &lt;li&gt;&lt;a href="#tab-hrz-3"&gt;Tab 3&lt;/a&gt;&lt;/li&gt;
        &lt;li&gt;&lt;a href="#tab-hrz-4"&gt;Tab 4&lt;/a&gt;&lt;/li&gt;
    &lt;/ul&gt;

    &lt;div class="tabs-content"&gt;
        &lt;div id="tab-hrz-1" class="tab-content"&gt;Tab 1 content...&lt;/div&gt;

        &lt;div id="tab-hrz-2" class="tab-content"&gt;Tab 2 content...&lt;/div&gt;

        &lt;div id="tab-hrz-3" class="tab-content"&gt;Tab 3 content...&lt;/div&gt;

        &lt;div id="tab-hrz-4" class="tab-content"&gt;Tab 4 content...&lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <div class="tabs tabs-vertical">
                <ul class="tabs-menu">
                    <li class="active"><a href="#tab-vrt-1">Tab 1</a></li>
                    <li><a href="#tab-vrt-2">Tab 2</a></li>
                    <li><a href="#tab-vrt-3">Tab 3</a></li>
                </ul>

                <div class="tabs-content">
                    <div id="tab-vrt-1" class="tab-content">Tab 1 content<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>

                    <div id="tab-vrt-2" class="tab-content">Tab 2 content<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>

                    <div id="tab-vrt-3" class="tab-content">Tab 3 content<br/>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </div>
            </div><!-- .tabs-vertical -->

            <p class="text-right"><a class="toggle-link" href="#code-tabs-vertical"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-tabs-vertical" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;!-- Vertical Tabs --&gt;
</code></pre>
        </div><!-- .toggle-cont -->


        <!-- TOGGLES -->
        <h2 class="text-upper">Toggle</h2>

        <div class="padd-box-sm">
            <ul class="togglebox">
                <li>
                    <h3 class="togglebox-header">Toggle Box Title 1</h3>
                    <div class="togglebox-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>

                <li>
                    <h3 class="togglebox-header">Toggle Box Title 2</h3>
                    <div class="togglebox-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>

                <li>
                    <h3 class="togglebox-header">Toggle Box Title 3</h3>
                    <div class="togglebox-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>
            </ul><!-- .toggle-box -->

            <p class="text-right"><a class="toggle-link" href="#code-toggle-box"><small>Show Code Example</small></a></p>
        </div><!-- .padd-box-sm -->

        <div id="code-toggle-box" class="toggle-cont">
<pre><code class="language-html" data-lang="html">&lt;ul class="togglebox"&gt;
    &lt;li&gt;
        &lt;h3 class="togglebox-header"&gt;Toggle Box Title 1&lt;/h3&gt;
        &lt;div class="togglebox-content"&gt;Lorem ipsum dolor ... &lt;/div&gt;
    &lt;/li&gt;

    &lt;li&gt;
        &lt;h3 class="togglebox-header"&gt;Toggle Box Title 2&lt;/h3&gt;
        &lt;div class="togglebox-content"&gt;Lorem ipsum dolor ... &lt;/div&gt;
    &lt;/li&gt;

    &lt;li&gt;
        &lt;h3 class="togglebox-header"&gt;Toggle Box Title 3&lt;/h3&gt;
        &lt;div class="togglebox-content"&gt;Lorem ipsum dolor ... &lt;/div&gt;
    &lt;/li&gt;
&lt;/ul&gt;

&lt;!-- Use .active class if you want to pre open one of toggle items --&gt;
&lt;ul class="togglebox"&gt;
    &lt;li class="active"&gt;
        &lt;h3 class="togglebox-header"&gt;Toggle Box Title 1&lt;/h3&gt;
        &lt;div class="togglebox-content"&gt;Lorem ipsum dolor ... &lt;/div&gt;
    &lt;/li&gt;

    &lt;li&gt;
        &lt;h3 class="togglebox-header"&gt;Toggle Box Title 2&lt;/h3&gt;
        &lt;div class="togglebox-content"&gt;Lorem ipsum dolor ... &lt;/div&gt;
    &lt;/li&gt;

    ...
&lt;/ul&gt;
</code></pre>
        </div><!-- .toggle-cont -->

        <div class="padd-box-sm">
            <ul class="accordion">
                <li class="active">
                    <h3 class="accordion-header">Accordion Section 1 <span class="icon"></span></h3>
                    <div class="accordion-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>

                <li>
                    <h3 class="accordion-header">Accordion Section 2 <span class="icon"></span></h3>
                    <div class="accordion-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>

                <li>
                    <h3 class="accordion-header">Accordion Section 3 <span class="icon"></span></h3>
                    <div class="accordion-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
                        Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
                        fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.</div>
                </li>
            </ul><!-- .accordion -->
        </div><!-- .padd-box-sm -->


        <a class="toggle-link" href="#code-"><small>Toggle Content</small></a>
        <div id="code-" class="toggle-cont">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
            Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
            fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam sit amet purus urna.
            Proin dictum fringilla enim, sit amet suscipit dolor dictum in. Maecenas porttitor, est et malesuada congue, ligula elit
            fermentum massa, sit amet porta odio est at velit. Sed nec turpis neque. Fusce at mi felis, sed interdum tortor.
        </div><!-- .toggle-cont -->

        <!-- START: Inputs  -->
        <h2>Form Elements</h2>

        <div class="padd-box-sm">
            <div class="form-group">
                <label class="form-label" for="exampleInputName">First Name</label>
                <div class="form-item-wrap">
                    <input class="form-item" id="exampleInputName" type="text">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="exampleInputEmail">Email address</label>
                <div class="form-item-wrap">
                    <input class="form-item" id="exampleInputEmail" type="email" placeholder="Email">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="exampleInputMessage">Message</label>
                <div class="form-item-wrap">
                    <textarea class="form-item" id="exampleInputMessage"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="exampleInputError">Error Message</label>
                <div class="form-item-wrap">
                    <input class="form-item error" id="exampleInputError" type="text">
                </div>
            </div>
        </div>

        <h2>Slider</h2>
        <div class="padd-box-sm">
            <div class="cr-slider" data-slick='{"dots": false}'>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
            </div><!-- .cr-slider -->

            <div class="cr-slider" data-slick='{"dots": true}'>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
            </div><!-- .cr-slider -->
        </div><!-- .padd-box-sm -->

        <h2>Carousel</h2>
        <div class="padd-box-sm">
            <div class="cr-carousel" data-slick='{"slidesToShow": 3, "slidesToScroll": 3, "dots": true}'>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
            </div><!-- .cr-carousel -->

            <div class="cr-carousel" data-slick='{"slidesToShow": 5, "slidesToScroll": 5, "dots": false}'>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
                <div>
                    <img src="assets/images/uploads/site/img-838x342.png" alt="">
                </div>
            </div><!-- .cr-carousel -->
        </div><!-- .padd-box-sm -->
    </div><!-- .padd-box -->

        </div>
        <!-- .crt-paper-cont -->
    </div>
    <!-- .crt-paper -->
</div>
<!-- .crt-paper-layers -->
        </div>
        <!-- .crt-container-sm -->
    </div>
    <!-- .crt-container -->

    <div id="crt-sidebar">
    <button id="crt-sidebar-close" class="btn btn-icon btn-light btn-shade">
        <span class="crt-icon crt-icon-close"></span>
    </button>

    <div id="crt-sidebar-inner">
                <nav id="crt-main-nav-sm" class="visible-xs text-center">
            
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>        </nav>
        
        
<div class="crt-card bg-primary text-center">
    <div class="crt-card-avatar">
        <img class="avatar avatar-195" src="assets/images/uploads/avatar/avatar-195x195.png"
             srcset="assets/images/uploads/avatar/avatar-390x390-2x.png 2x" width="195" height="195" alt="">
    </div>
    <div class="crt-card-info">
        <h2 class="text-upper">Ola Lowe</h2>

        <p class="text-muted">Florist | Decorator</p>
        <ul class="crt-social clear-list">
            <li><a><span class="crt-icon crt-icon-facebook"></span></a></li>
            <li><a><span class="crt-icon crt-icon-twitter"></span></a></li>
            <li><a><span class="crt-icon crt-icon-google-plus"></span></a></li>
            <li><a><span class="crt-icon crt-icon-instagram"></span></a></li>
            <li><a><span class="crt-icon crt-icon-pinterest"></span></a></li>
        </ul>
    </div>
</div>
        <aside class="widget-area">
            <section class="widget widget_search">
                <form role="search" method="get" class="search-form" action="#">
                    <label>
                        <span class="screen-reader-text">Search for:</span>
                        <input type="search" class="search-field" placeholder="Search" value="" name="s">
                    </label>
                    <button type="submit" class="search-submit">
                        <span class="screen-reader-text">Search</span>
                        <span class="crt-icon crt-icon-search"></span>
                    </button>
                </form>
            </section>

            <section class="widget widget_posts_entries">
                <h2 class="widget-title">popular posts</h2>
                <ul>
                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-01.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">contextual advertising</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-02.jpg" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">grilling tips for the dog days of summer</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-03.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3><a href=""></a>branding do you know who are</h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section id="tag_cloud-2" class="widget widget_tag_cloud">
                <h2 class="widget-title">Tags</h2>
                <div class="tagcloud">
                    <a href="" class="tag-link-5 tag-link-position-1" title="1 topic" style="font-size: 1em;">Audios</a>
                    <a href="" class="tag-link-7 tag-link-position-2" title="1 topic" style="font-size: 1em;">Freelance</a></div>
            </section>

            <section id="recent-posts-3" class="widget widget_recent_entries">
                <h4 class="widget-title">Recent Posts</h4>
                <ul>
                    <li>
                        <a href="">Global Travel And Vacations  Luxury Travel On A Tight  Budget</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">cooking for one</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">An Ugly Myspace Profile Will  Sure Ruin Your Reputation</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section class="widget widget_categories">
                <h4 class="widget-title">post categories</h4>
                <ul>
                    <li class="cat-item"><a href="">Audios</a>5</li>
                    <li class="cat-item"><a href="">Daili Inspiration</a>2</li>
                    <li class="cat-item"><a href="">Freelance</a>27</li>
                    <li class="cat-item"><a href="">Links</a>5</li>
                    <li class="cat-item"><a href="">Mobile</a>2</li>
                    <li class="cat-item"><a href="">Phography</a>27</li>
                </ul>
            </section>
        </aside>

    </div><!-- #crt-sidebar-inner -->
</div><!-- #crt-sidebar -->
    <footer id="crt-footer" class="crt-container-lg">
        <div class="crt-container">
            <div class="crt-container-sm clear-mrg text-center">
                <p>Ola Resume @ All Rights Reserved 2016</p>
            </div>
        </div>
        <!-- .crt-container -->
    </footer>
    <!-- #crt-footer -->

        <svg id="crt-bg-shape-1" class="hidden-sm hidden-xs" height="519" width="758">
        <polygon class="pol" points="0,455,693,352,173,0,92,0,0,71"/>
    </svg>

    <svg id="crt-bg-shape-2" class="hidden-sm hidden-xs" height="536" width="633">
        <polygon points="0,0,633,0,633,536"/>
    </svg>
    </div>
<!-- .crt-wrapper -->

<!-- Scripts -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.12.4.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiwY_5J2Bkv2UgSeJa4NOKl6WUezSS9XA"></script>

<script type="text/javascript" src="assets/js/plugins.min.js"></script>
<script type="text/javascript" src="assets/js/theme.min.js"></script>
</body>
</html>