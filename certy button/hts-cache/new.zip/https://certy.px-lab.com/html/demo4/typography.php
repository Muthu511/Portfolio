<!DOCTYPE html>
<html lang="en" class="crt crt-nav-on crt-nav-type1 crt-main-nav-on crt-sidebar-on crt-layers-2">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Certy</title>
    <meta name="description" content="">

    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,700" rel="stylesheet">

    <!-- Icon Fonts -->
    <link href="assets/fonts/icomoon/style.css" rel="stylesheet">

    <!-- Styles -->
    <link href="assets/css/plugins.min.css" rel="stylesheet">
    <link href="assets/css/style.min.css" rel="stylesheet">

    <!-- Modernizer -->
    <script type="text/javascript" src="assets/js/vendor/modernizr-3.3.1.min.js"></script>
	
	<!-- Google Analytics -->
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-92973565-1', 'auto');
	  ga('send', 'pageview');
	</script>
  </head>

  <body class="single">
     <div class="crt-wrapper">
         <header id="crt-header">
             <div class="crt-head-inner crt-container">
                 <div class="crt-container-sm">
                     <div class="crt-head-row">
                         <div id="crt-head-col1" class="crt-head-col text-left">
                             <a id="crt-logo" class="crt-logo" href="index.php">
                                 <img src="assets/images/uploads/brand/logo.svg" alt="certy resume"><span>.Certy</span>
                             </a>
                         </div>

                                                  <div id="crt-head-col2" class="crt-head-col text-right">
                             <div class="crt-nav-container crt-container hidden-sm hidden-xs">
                                 <nav id="crt-main-nav">
                                    
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>                                 </nav>
                             </div>
                         </div>
                         
                                                  <div id="crt-head-col3" class="crt-head-col text-right">
                             <button id="crt-sidebar-btn" class="btn btn-icon btn-shade">
                                 <span class="crt-icon crt-icon-side-bar-icon"></span>
                             </button>
                         </div>
                                              </div>
                 </div><!-- .crt-head-inner -->
             </div>

                              <nav id="crt-nav-sm" class="crt-nav hidden-lg hidden-md">
                         <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                 </nav><!-- #crt-nav-sm -->
                     </header><!-- #crt-header -->

        <div id="crt-container" class="crt-container">
            
                            <div id="crt-nav-wrap" class="hidden-sm hidden-xs">
                    <div id="crt-nav-inner">
                        <div class="crt-nav-cont">
                            <div id="crt-nav-scroll">
                                <nav id="crt-nav" class="crt-nav">
                                        <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                                </nav>
                            </div>

                            <div id="crt-nav-tools" class="hidden">
                                <span class="crt-icon crt-icon-dots-three-horizontal"></span>

                                <button id="crt-nav-arrow" class="clear-btn">
                                    <span class="crt-icon crt-icon-chevron-thin-down"></span>
                                </button>
                            </div>
                        </div>
                        <div class="crt-nav-btm"></div>
                    </div>
                </div><!-- .crt-nav-wrap -->
            
            <div class="crt-container-sm"><div class="crt-paper-layers">
    <div class="crt-paper clearfix">
        <div class="crt-paper-cont paper-padd clear-mrg">

    <div class="padd-box">

    <!-- Headings -->
    <h2 class="text-upper">Headings</h2>
    <div class="padd-box-sm">
        <h1>h1 Heading</h1>
        <h2>h2 Heading</h2>
        <h3>h3 Heading</h3>
        <h4>h4 Heading</h4>
        <h5>h5 Heading</h5>
        <h6>h6 Heading</h6>

<pre><code class="html">&lt;h1&gt;h1 Heading&lt;/h1&gt;
&lt;h2&gt;h2 Heading&lt;/h2&gt;
&lt;h3&gt;h3 Heading&lt;/h3&gt;
&lt;h4&gt;h4 Heading&lt;/h4&gt;
&lt;h5&gt;h5 Heading&lt;/h5&gt;
&lt;h6&gt;h6 Heading&lt;/h6&gt;</code></pre>
    </div>

    <!-- Paragraphs -->
    <h2 class="text-upper">Paragraphs</h2>
    <div class="padd-box-sm">
        <p class="text-lead">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown
            printer took a galley of type and scrambled it to make a type specimen book.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
            leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
            with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
            publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
            leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
            with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
            publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

<pre><code class="html">&lt;!-- Make a paragraph stand out by adding class="text-lead" --&gt;
&lt;p class="text-lead"&gt;Lorem Ipsum ... &lt;/p&gt;

&lt;!-- Simple Paragraphs --&gt;
&lt;p&gt;Lorem Ipsum ... &lt;/p&gt;
&lt;p&gt;Lorem Ipsum ... &lt;/p&gt;</code></pre>
    </div>

    <!-- Block Quotes -->
    <h2 class="text-upper">Blockquotes</h2>

    <div class="padd-box-sm">
        <p>Single line blockquote:</p>
        <blockquote><p>Stay hungry. Stay foolish.</p></blockquote>

        <p>Multi line blockquote with a cite reference:</p>
        <blockquote class="bg-primary">
            <p>Excellence is an art won by training and habituation.</p>
            <p>We do not act rightly because we have virtue or excellence, but we rather have those because we have acted
                rightly.</p>
            <p>We are what we repeatedly do. Excellence, then, is not an act but a habit.</p>
            <p><cite><a href="https://www.brainyquote.com/quotes/quotes/a/aristotle408592.html"
                        target="_blank">Aristotle</a> - Aristotle Quotes</cite></p>
        </blockquote>

        <p>Blockquote with a side quote icon:</p>
        <blockquote class="quote-side">
            <p>In the practice of tolerance, one's enemy is the best teacher.</p>
            <p><cite>Dalai Lama</cite></p>
        </blockquote>

        <p>Blockquote with a top quote icon:</p>
        <blockquote class="quote-top bg-primary">
            <p>It's not the customers job to know what they want.</p>
            <p><cite>Steve Jobs – Apple Worldwide Developers Conference</cite></p>
        </blockquote>

<pre><code class="html">&lt;!-- Single line blockquote --&gt;
&lt;blockquote&gt;
    &lt;p&gt;Stay hungry. Stay foolish.&lt;/p&gt;
&lt;/blockquote&gt;

&lt;!-- Multi line blockquote with a cite reference --&gt;
&lt;blockquote&gt;
    &lt;p&gt;Excellence is an ... &lt;/p&gt;
    &lt;p&gt;We do not act rightly ... &lt;/p&gt;
    &lt;p&gt;We are what we ... &lt;/p&gt;
    &lt;p&gt;&lt;cite&gt;&lt;a href="http://url" target="_blank"&gt;Aristotle&lt;/a&gt; - Aristotle Quotes&lt;/cite&gt;&lt;/p&gt;
&lt;/blockquote&gt;

&lt;!-- Blockquote with a side quote icon - use class="quote-side" --&gt;
&lt;blockquote class="quote-side"&gt; ... &lt;/blockquote&gt;

&lt;!-- Blockquote with a top quote icon - use class="quote-top" --&gt;
&lt;blockquote class="quote-top"&gt; ... &lt;/blockquote&gt;

&lt;!-- Blockquote with a primary background - use class="bg-primary" --&gt;
&lt;blockquote class="bg-primary"&gt; ... &lt;/blockquote&gt;</code></pre>
        </div>

    <!-- Lists -->
    <h2 class="text-upper">Lists</h2>

    <div class="padd-box-sm">
        <div class="row">
            <div class="col-sm-6">
                <h4>Default Unordered List</h4>
                <ul>
                    <li>List item one</li>
                    <li>List item two
                        <ul>
                            <li>List item one</li>
                            <li>List item two
                                <ul>
                                    <li>List item one</li>
                                    <li>List item two</li>
                                    <li>List item three</li>
                                    <li>List item four</li>
                                </ul>
                            </li>
                            <li>List item three</li>
                        </ul>
                    </li>
                    <li>List item three</li>
                    <li>List item four</li>
                    <li>List item fife</li>
                </ul>
            </div>

            <div class="col-sm-6">
                <h4>Default Ordered List</h4>
                <ol>
                    <li>List item one
                        <ol>
                            <li>List item one
                                <ol>
                                    <li>List item one</li>
                                    <li>List item two</li>
                                    <li>List item three</li>
                                    <li>List item four</li>
                                </ol>
                            </li>
                            <li>List item two</li>
                            <li>List item three</li>
                            <li>List item four</li>
                        </ol>
                    </li>
                    <li>List item two</li>
                    <li>List item three</li>
                    <li>List item four</li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <h4>Styled Unordered List</h4>
                <ul class="styled-ul">
                    <li>List item one</li>
                    <li>List item two
                        <ul>
                            <li>List item one</li>
                            <li>List item two
                                <ul>
                                    <li>List item one</li>
                                    <li>List item two</li>
                                    <li>List item three</li>
                                    <li>List item four</li>
                                </ul>
                            </li>
                            <li>List item three</li>
                        </ul>
                    </li>
                    <li>List item three</li>
                    <li>List item four</li>
                    <li>List item fife</li>
                </ul>
            </div>

            <div class="col-sm-6">
                <h4>Styled Ordered List</h4>
                <ol class="styled-ol">
                    <li>List item one
                        <ol>
                            <li>List item one
                                <ol>
                                    <li>List item one</li>
                                    <li>List item two</li>
                                    <li>List item three</li>
                                    <li>List item four</li>
                                </ol>
                            </li>
                            <li>List item two</li>
                            <li>List item three</li>
                            <li>List item four</li>
                        </ol>
                    </li>
                    <li>List item two</li>
                    <li>List item three</li>
                    <li>List item four</li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <h4>Styled List</h4>
                <ul class="styled-list">
                    <li>List item one</li>
                    <li>List item two</li>
                    <li>List item three</li>
                    <li>List item four</li>
                </ul>
            </div>

            <div class="col-sm-6">
                <h4>Unstyled List</h4>
                <ul class="clear-list">
                    <li>List item one</li>
                    <li>List item two</li>
                    <li>List item three</li>
                    <li>List item four</li>
                    <li>List item fife</li>
                    <li>List item six</li>
                </ul>
            </div>
        </div>

<pre><code class="html">&lt;-- Default Unordered List --&gt;
&lt;ul&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ul&gt;

&lt;-- Default Ordered List --&gt;
&lt;ol&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ol&gt;

&lt;-- Styled Unordered List - use class="styled-ul" --&gt;
&lt;ul class="styled-ul"&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ul&gt;

&lt;-- Styled Ordered List - use class="styled-ol" --&gt;
&lt;ul class="styled-ol"&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ul&gt;

&lt;-- Styled List - use class="styled-list" --&gt;
&lt;ul class="styled-list"&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ul&gt;

&lt;-- Unstyled List - use class="clear-list" --&gt;
&lt;ul class="clear-list"&gt;
    &lt;li&gt; ... &lt;/li&gt;
&lt;/ul&gt;</code></pre>


    <h4>Icon List</h4>
    <ul class="icon-list">
        <li><span class="crt-icon crt-icon-music"></span> North Adella</li>
        <li><span class="crt-icon crt-icon-blog"></span> North Adella</li>
        <li><span class="crt-icon crt-icon-blog"></span> North Adella</li>
        <li><span class="crt-icon crt-icon-blog"></span> North Adella</li>
        <li><span class="crt-icon crt-icon-blog"></span> North Adella</li>
    </ul>

    <h4>Description</h4>
        <dl>
            <dt>Definition List Title</dt>
            <dd>Definition list division.</dd>
            <dt>Startup</dt>
            <dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd>
            <dt>#dowork</dt>
            <dd>Coined by Rob Dyrdek and his personal body guard Christopher “Big Black” Boykins, “Do Work” works as a self motivator, to motivating your friends.</dd>
            <dt>Do It Live</dt>
            <dd>I’ll let Bill O’Reilly will <a title="We'll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd>
        </dl>

<pre><code class="html">&lt;dl&gt;
    &lt;dt&gt;Definition List Title&lt;/dt&gt;
    &lt;dd&gt;Definition list division.&lt;/dd&gt;
    ...
&lt;/dl&gt;</code></pre>


    <h4>Horizontal Description</h4>
        <dl class="dl-horizontal">
            <dt>Definition List Title</dt>
            <dd>Definition list division.</dd>
            <dt>Startup</dt>
            <dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd>
            <dt>#dowork</dt>
            <dd>Coined by Rob Dyrdek and his personal body guard Christopher “Big Black” Boykins, “Do Work” works as a self motivator, to motivating your friends.</dd>
            <dt>Do It Live</dt>
            <dd>I’ll let Bill O’Reilly will <a title="We'll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd>
        </dl>

<pre><code class="html">&lt;dl class="dl-horizontal"&gt;
    &lt;dt&gt;Definition List Title&lt;/dt&gt;
    &lt;dd&gt;Definition list division.&lt;/dd&gt;
    ...
&lt;/dl&gt;</code></pre>
    </div>

    <!-- Tables -->
    <h2>Tables</h2>
    <div class="padd-box-sm">
        <h3>Table</h3>
        <table>
            <thead>
            <tr>
                <th>Employee</th>
                <th>Salary</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th><a href="http://example.org/">John Doe</a></th>
                <td>$1</td>
                <td>Because that’s all Steve Jobs needed for a salary.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Jane Doe</a></th>
                <td>$100K</td>
                <td>For all the blogging she does.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Fred Bloggs</a></th>
                <td>$100M</td>
                <td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Jane Bloggs</a></th>
                <td>$100B</td>
                <td>With hair like that?! Enough said…</td>
            </tr>
            </tbody>
        </table>

        <h3>Table Fixed</h3>
        <table class="table-fixed">
            <thead>
            <tr>
                <th>Employee</th>
                <th>Salary</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th><a href="http://example.org/">John Doe</a></th>
                <td>$1</td>
                <td>Because that’s all Steve Jobs needed for a salary.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Jane Doe</a></th>
                <td>$100K</td>
                <td>For all the blogging she does.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Fred Bloggs</a></th>
                <td>$100M</td>
                <td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
            </tr>
            <tr>
                <th><a href="http://example.org/">Jane Bloggs</a></th>
                <td>$100B</td>
                <td>With hair like that?! Enough said…</td>
            </tr>
            </tbody>
        </table>

        <h3>Table Responsive</h3>
        <table class="table-responsive">
            <thead>
            <tr>
                <th>Employee</th>
                <th>Salary</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th data-title="Name"><a href="http://example.org/">John Doe</a></th>
                <td data-title="Salary">$1</td>
                <td data-title="Info">Because that’s all Steve Jobs needed for a salary.</td>
            </tr>
            <tr>
                <th data-title="Name"><a href="http://example.org/">Jane Doe</a></th>
                <td data-title="Salary">$100K</td>
                <td data-title="Info">For all the blogging she does.</td>
            </tr>
            <tr>
                <th data-title="Name"><a href="http://example.org/">Fred Bloggs</a></th>
                <td data-title="Salary">$100M</td>
                <td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>
            </tr>
            <tr>
                <th data-title="Name"><a href="http://example.org/">Jane Bloggs</a></th>
                <td data-title="Salary">$100B</td>
                <td data-title="Info">With hair like that?! Enough said…</td>
            </tr>
            </tbody>
        </table>
    </div>

    <!-- HTML Tags -->
    <h2 class="text-upper">HTML Tags</h2>

    <h2>Highlights</h2>
    <div class="padd-box-sm">
        <p>Lorem ipsum dolor sit amet,
            <mark>highlighted text</mark>. In fringilla libero dui, porttitor
            <mark>highlighted text</mark> dui tempor nec. Donec eleifend ligula
            non magna maximus, eget vehicula turpis viverra.
        </p>
    </div>

    <div class="padd-box-sm">
        <p><strong>Link Tag</strong><br>
            Use <code>&lt;a&gt;</code> tag to defines a <a title="Themeforest" href="https://themeforest.net/">link</a>.</p>

        <p><strong>Marked Text</strong><br>
            Use the <code>&lt;mark&gt;</code> tag to <mark>highlight</mark> parts of your text.</p>

        <p><strong>Deleted Text</strong><br>
            The <code>&lt;del&gt;</code> tag will let to define <del>replaced</del> or <del>deleted</del> text.</p>

        <p><strong>Strikethrough Text</strong><br>
            The <code>&lt;s&gt;</code> tag specifies text that is no longer <s>correct, accurate or relevant</s>.</p>

        <p><strong>Inseted Text</strong><br>
            The <code>&lt;ins&gt;</code> tag defines a text that has been <ins>inserted</ins> into a document.</p>

        <p><strong>Undelined Text</strong><br>
            The <code>&lt;u&gt;</code> tag used for <u>underline</u> a snippet of text.</p>

        <p><strong>Small Text</strong><br>
            The <code>&lt;small&gt;</code> defines <small>smaller</small> text.</p>

        <p><strong>Bold Text</strong><br>
            The <code>&lt;strong&gt;</code> tag used for emphasizing a snippet of text with a heavier <strong>font-weight</strong>.</p>

        <p><strong>Italic Text</strong><br>
            The <code>&lt;em&gt;</code> tag used for emphasizing a snippet of text with <em>italics</em>.</p>

        <p><strong>Quote Tag</strong><br>
            The <code>&lt;q&gt;</code> tag defines a short quotation:<br>
            <q>Developers, developers, developers…</q> – Steve Ballmer</p>

        <p><strong>Cite Tag</strong><br>
            The <code>&lt;cite&gt;</code> tag defines the title of a work (e.g. a book, a song, a movie, a TV show, a painting, a sculpture, etc.)<br>
            For Example: "Code is poetry." —<cite>Automattic</cite></p>

        <p><strong>Abbreviation Tag</strong><br>
            The <code>&lt;abbr&gt;</code> tag defines an abbreviation or an acronym, like <abbr title="Hyper Text Markup Language">HTML</abbr>,&nbsp;
            <abbr title="Mister">Mr.</abbr>,&nbsp; <abbr title="December">Dec.</abbr>,&nbsp; <abbr title="as soon as possible">ASAP</abbr>,&nbsp;
            <abbr title="Automated Teller Machine">ATM</abbr>.</p>

        <p><strong>Subscript Tag</strong><br>
            The <code>&lt;sub&gt;</code> tag defines subscript text.<br> Subscript text appears half a character below the
            normal line and with smaller font size.<br>
            Subscript text can be used for chemical formulas, like H<sub>2</sub>O.</p>

        <p><strong>Superscript Tag</strong><br>
            The <code>&lt;sup&gt;</code> tag defines superscript text.<br> Superscript text appears half a character above
            the normal line and with smaller font size.
            It can be used for footnotes, like WWW<sup>[1]</sup> or for scientific expressions, like Albert Einstein's E =
            MC<sup>2</sup>.</p>

        <p><strong>Code Tag</strong><br>
            The <code>&lt;code&gt;</code> tag defines a piece of computer code.</p>

        <p><strong>Keyboard Tag</strong><br>
            Use the <code>&lt;kbd&gt;</code> tag to indicate input that is typically entered via keyboard.<br>
            For Example: To reformat text, press <kbd><kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>F</kbd></kbd></p>

        <p><strong>Preformatted Tag</strong><br>
            The <code>&lt;pre&gt;</code> tag defines preformatted text.</p>
    <pre>.post-title {
        margin: 0 0 5px;
        font-weight: bold;
        font-size: 38px;
        line-height: 1.2;
        and here's a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;
    }</pre>

        <p><strong>Variable Tag</strong><br>
            For indicating variables use the <code>&lt;var&gt;</code> tag: <var>y</var> = <var>m</var><var>x</var> + <var>b</var> </p>

        <p><strong>Samp Tag</strong><br>
            The <code>&lt;samp&gt;</code> tag defines sample output from a computer program.</p>

            <!--
            <p><strong>Address Tag</strong></p>
            <address>1 Infinite Loop<br>
            Cupertino, CA 95014<br>
            United States</address>

            <h2>Image Alignment</h2>
            <p>Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let’s get started.</p>
            <p>On the topic of alignment, it should be noted that users can choose from the options of&nbsp;<em>None</em>,&nbsp;<em>Left</em>,&nbsp;<em>Right, </em>and&nbsp;<em>Center</em>. In addition, they also get the options of&nbsp;<em>Thumbnail</em>,&nbsp;<em>Medium</em>,&nbsp;<em>Large</em>&nbsp;&amp;&nbsp;<em>Fullsize</em>.</p>
            <p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="img/uploads/image-alignment-580x3001.jpg" width="580" height="300"></p>
            <p>The image above happens to be&nbsp;<em><strong>centered</strong></em>.</p>
            <p><strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="img/uploads/image-alignment-150x1501.jpg" width="150" height="150"></strong>The rest of this paragraph is filler&nbsp;for the sake of seeing the text wrap around the 150×150 image, which is <em><strong>left aligned</strong></em>.&nbsp;<strong></strong></p>
            <p>As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more&nbsp;sentence&nbsp;here, we’ll see that the text moves from the right of the image down below the image in&nbsp;seamless&nbsp;transition. Again, letting the do it’s thang.&nbsp;Mission accomplished!</p>
            <p>And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.</p>
            <p><img class="alignnone  wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="img/uploads/image-alignment-1200x40021.jpg" width="1200" height="400"></p>
            <p>The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.</p>
            <p><img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="img/uploads/image-alignment-300x2001.jpg" width="300" height="200"></p>
            <p>And now we’re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there… Hey guy! Way to rock that right side. I don’t care what the left aligned image says, you look great. Don’t let anyone else tell you differently.</p>
            <p>In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty.&nbsp;Yeah… Just like that. It never felt so good to be right.</p>
            <p>And just when you thought we were done, we’re going to do them all over again with captions!</p>
            <figure id="attachment_906" style="width: 580px;" class="wp-caption aligncenter"><img class="size-full wp-image-906  " title="Image Alignment 580x300" alt="Image Alignment 580x300" src="img/uploads/image-alignment-580x3001.jpg" width="580" height="300"><figcaption class="wp-caption-text">Look at 580×300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.</figcaption></figure>
            <p>The image above happens to be&nbsp;<em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.</p>
            <figure id="attachment_904" style="width: 150px;" class="wp-caption alignleft"><img class="size-full wp-image-904  " title="Image Alignment 150x150" alt="Image Alignment 150x150" src="img/uploads/image-alignment-150x1501.jpg" width="150" height="150"><figcaption class="wp-caption-text">Itty-bitty caption.</figcaption></figure>
            <p><strong></strong>The rest of this paragraph is filler&nbsp;for the sake of seeing the text wrap around the 150×150 image, which is <em><strong>left aligned</strong></em>.&nbsp;<strong></strong></p>
            <p>As you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more&nbsp;sentence&nbsp;here, we’ll see that the text moves from the right of the image down below the image in&nbsp;seamless&nbsp;transition. Again, letting the do it’s thang. Mission accomplished!</p>
            <p>And now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.</p>
            <figure id="attachment_907" style="width: 1200px;" class="wp-caption alignnone"><img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="img/uploads/image-alignment-1200x40021.jpg" width="1200" height="400"><figcaption class="wp-caption-text">Massive image comment for your eyeballs.</figcaption></figure>
            <p>The image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.</p>
            <figure id="attachment_905" style="width: 300px;" class="wp-caption alignright"><img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="img/uploads/image-alignment-300x2001.jpg" width="300" height="200"><figcaption class="wp-caption-text">Feels good to be right all the time.</figcaption></figure>
            <p>And now we’re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there… Hey guy! Way to rock that right side. I don’t care what the left aligned image says, you look great. Don’t let anyone else tell you differently.</p>
            <p>In just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah… Just like that. It never felt so good to be right.</p>
            <p>And that’s a wrap, yo! You survived the&nbsp;tumultuous&nbsp;waters of alignment. Image alignment achievement unlocked!</p>

            <h2>Text Alignment</h2>
            <h3>Default</h3>
            <p>This is a paragraph. It should not have any alignment of any kind. It should just flow like you would normally expect. Nothing fancy. Just straight up text, free flowing, with love. Completely neutral and not picking a side or sitting on the fence. It just is. It just freaking is. It likes where it is. It does not feel compelled to pick a side. Leave him be. It will just be better that way. Trust me.</p>
            <h3>Left Align</h3>
            <p class="text-left">This is a paragraph. It is left aligned. Because of this, it is a bit more liberal in it’s views. It’s favorite color is green. Left align tends to be more eco-friendly, but it provides no concrete evidence that it really is. Even though it likes share the wealth evenly, it leaves the equal distribution up to justified alignment.</p>
            <h3>Center Align</h3>
            <p class="text-center">This is a paragraph. It is center aligned. Center is, but nature, a fence sitter. A flip flopper. It has a difficult time making up its mind. It wants to pick a side. Really, it does. It has the best intentions, but it tends to complicate matters more than help. The best you can do is try to win it over and hope for the best. I hear center align does take bribes.</p>
            <h3>Right Align</h3>
            <p class="text-right">This is a paragraph. It is right aligned. It is a bit more conservative in it’s views. It’s prefers to not be told what to do or how to do it. Right align totally owns a slew of guns and loves to head to the range for some practice. Which is cool and all. I mean, it’s a pretty good shot from at least four or five football fields away. Dead on. So boss.</p>
            <h3>Justify Align</h3>
            <p class="text-justify">This is a paragraph. It is justify aligned. It gets really mad when people associate it with Justin Timberlake. Typically, justified is pretty straight laced. It likes everything to be in it’s place and not all cattywampus&nbsp;like the rest of the aligns. I am not saying that makes it better than the rest of the aligns, but it does tend to put off more of an&nbsp;elitist&nbsp;attitude.</p>
            -->
        </div>

    <!-- Dropcups -->
    <h2>Dropcups</h2>
    <div class="padd-box-sm">
        <p><span class="text-dropcup">L</span>orem ipsum dolor sit amet,
            link example. In fringilla libero dui, porttitor
            condimentum dui tempor nec. Donec eleifend ligula
            non magna maximus, eget vehicula turpis viverra.
            Donec luctus purus eget dui faucibus congue. Maecenas
            id dui ut felis mollis ornare. Phasellus maximus felis sapien,
            facilisis ultricies elit lacinia id.
        </p>

        <p><span class="text-dropcup text-primary">L</span>orem ipsum dolor sit amet,
            link example. In fringilla libero dui, porttitor
            condimentum dui tempor nec. Donec eleifend ligula
            non magna maximus, eget vehicula turpis viverra.
            Donec luctus purus eget dui faucibus congue. Maecenas
            id dui ut felis mollis ornare. Phasellus maximus felis sapien,
            facilisis ultricies elit lacinia id.
        </p>

        <p><span class="text-dropcup-sq">L</span>orem ipsum dolor sit amet,
            link example. In fringilla libero dui, porttitor
            condimentum dui tempor nec. Donec eleifend ligula
            non magna maximus, eget vehicula turpis viverra.
            Donec luctus purus eget dui faucibus congue. Maecenas
            id dui ut felis mollis ornare. Phasellus maximus felis sapien,
            facilisis ultricies elit lacinia id.
        </p>

        <p><span class="text-dropcup-sq bg-primary">L</span>orem ipsum dolor sit amet,
            link example. In fringilla libero dui, porttitor
            condimentum dui tempor nec. Donec eleifend ligula
            non magna maximus, eget vehicula turpis viverra.
            Donec luctus purus eget dui faucibus congue. Maecenas
            id dui ut felis mollis ornare. Phasellus maximus felis sapien,
            facilisis ultricies elit lacinia id.
        </p>
    </div>

    <!-- Tooltips -->
    <h2>Tooltips</h2>
    <div class="padd-box-sm">
        <p><span class="tooltip" data-tooltip="Tooltip text">Lorem ipsum</span>&nbsp;dolor sit amet, link example.
            In fringilla libero dui, porttitor condimentum dui tempor nec. Donec eleifend ligula non magna maximus,
            eget vehicula turpis viverra. Donec luctus purus eget dui faucibus congue. Maecenas id dui ut felis mollis ornare.
            Phasellus maximus felis sapien, facilisis ultricies elit lacinia id.
        </p>
    </div>

    </div><!-- .padd-box -->

        </div>
        <!-- .crt-paper-cont -->
    </div>
    <!-- .crt-paper -->
</div>
<!-- .crt-paper-layers -->
        </div>
        <!-- .crt-container-sm -->
    </div>
    <!-- .crt-container -->

    <div id="crt-sidebar">
    <button id="crt-sidebar-close" class="btn btn-icon btn-light btn-shade">
        <span class="crt-icon crt-icon-close"></span>
    </button>

    <div id="crt-sidebar-inner">
                <nav id="crt-main-nav-sm" class="visible-xs text-center">
            
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>        </nav>
        
        
<div class="crt-card bg-primary text-center">
    <div class="crt-card-avatar">
        <img class="avatar avatar-195" src="assets/images/uploads/avatar/avatar-195x195.png"
             srcset="assets/images/uploads/avatar/avatar-390x390-2x.png 2x" width="195" height="195" alt="">
    </div>
    <div class="crt-card-info">
        <h2 class="text-upper">Ola Lowe</h2>

        <p class="text-muted">Florist | Decorator</p>
        <ul class="crt-social clear-list">
            <li><a><span class="crt-icon crt-icon-facebook"></span></a></li>
            <li><a><span class="crt-icon crt-icon-twitter"></span></a></li>
            <li><a><span class="crt-icon crt-icon-google-plus"></span></a></li>
            <li><a><span class="crt-icon crt-icon-instagram"></span></a></li>
            <li><a><span class="crt-icon crt-icon-pinterest"></span></a></li>
        </ul>
    </div>
</div>
        <aside class="widget-area">
            <section class="widget widget_search">
                <form role="search" method="get" class="search-form" action="#">
                    <label>
                        <span class="screen-reader-text">Search for:</span>
                        <input type="search" class="search-field" placeholder="Search" value="" name="s">
                    </label>
                    <button type="submit" class="search-submit">
                        <span class="screen-reader-text">Search</span>
                        <span class="crt-icon crt-icon-search"></span>
                    </button>
                </form>
            </section>

            <section class="widget widget_posts_entries">
                <h2 class="widget-title">popular posts</h2>
                <ul>
                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-01.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">contextual advertising</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-02.jpg" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">grilling tips for the dog days of summer</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-03.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3><a href=""></a>branding do you know who are</h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section id="tag_cloud-2" class="widget widget_tag_cloud">
                <h2 class="widget-title">Tags</h2>
                <div class="tagcloud">
                    <a href="" class="tag-link-5 tag-link-position-1" title="1 topic" style="font-size: 1em;">Audios</a>
                    <a href="" class="tag-link-7 tag-link-position-2" title="1 topic" style="font-size: 1em;">Freelance</a></div>
            </section>

            <section id="recent-posts-3" class="widget widget_recent_entries">
                <h4 class="widget-title">Recent Posts</h4>
                <ul>
                    <li>
                        <a href="">Global Travel And Vacations  Luxury Travel On A Tight  Budget</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">cooking for one</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">An Ugly Myspace Profile Will  Sure Ruin Your Reputation</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section class="widget widget_categories">
                <h4 class="widget-title">post categories</h4>
                <ul>
                    <li class="cat-item"><a href="">Audios</a>5</li>
                    <li class="cat-item"><a href="">Daili Inspiration</a>2</li>
                    <li class="cat-item"><a href="">Freelance</a>27</li>
                    <li class="cat-item"><a href="">Links</a>5</li>
                    <li class="cat-item"><a href="">Mobile</a>2</li>
                    <li class="cat-item"><a href="">Phography</a>27</li>
                </ul>
            </section>
        </aside>

    </div><!-- #crt-sidebar-inner -->
</div><!-- #crt-sidebar -->
    <footer id="crt-footer" class="crt-container-lg">
        <div class="crt-container">
            <div class="crt-container-sm clear-mrg text-center">
                <p>Ola Resume @ All Rights Reserved 2016</p>
            </div>
        </div>
        <!-- .crt-container -->
    </footer>
    <!-- #crt-footer -->

        <svg id="crt-bg-shape-1" class="hidden-sm hidden-xs" height="519" width="758">
        <polygon class="pol" points="0,455,693,352,173,0,92,0,0,71"/>
    </svg>

    <svg id="crt-bg-shape-2" class="hidden-sm hidden-xs" height="536" width="633">
        <polygon points="0,0,633,0,633,536"/>
    </svg>
    </div>
<!-- .crt-wrapper -->

<!-- Scripts -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.12.4.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiwY_5J2Bkv2UgSeJa4NOKl6WUezSS9XA"></script>

<script type="text/javascript" src="assets/js/plugins.min.js"></script>
<script type="text/javascript" src="assets/js/theme.min.js"></script>
</body>
</html>