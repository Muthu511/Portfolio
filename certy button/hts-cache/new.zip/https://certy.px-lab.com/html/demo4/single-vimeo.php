<!DOCTYPE html>
<html lang="en" class="crt crt-nav-on crt-nav-type1 crt-main-nav-on crt-sidebar-on crt-layers-2">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Certy</title>
    <meta name="description" content="">

    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:400,700" rel="stylesheet">

    <!-- Icon Fonts -->
    <link href="assets/fonts/icomoon/style.css" rel="stylesheet">

    <!-- Styles -->
    <link href="assets/css/plugins.min.css" rel="stylesheet">
    <link href="assets/css/style.min.css" rel="stylesheet">

    <!-- Modernizer -->
    <script type="text/javascript" src="assets/js/vendor/modernizr-3.3.1.min.js"></script>
	
	<!-- Google Analytics -->
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-92973565-1', 'auto');
	  ga('send', 'pageview');
	</script>
  </head>

  <body class="single">
     <div class="crt-wrapper">
         <header id="crt-header">
             <div class="crt-head-inner crt-container">
                 <div class="crt-container-sm">
                     <div class="crt-head-row">
                         <div id="crt-head-col1" class="crt-head-col text-left">
                             <a id="crt-logo" class="crt-logo" href="index.php">
                                 <img src="assets/images/uploads/brand/logo.svg" alt="certy resume"><span>.Certy</span>
                             </a>
                         </div>

                                                  <div id="crt-head-col2" class="crt-head-col text-right">
                             <div class="crt-nav-container crt-container hidden-sm hidden-xs">
                                 <nav id="crt-main-nav">
                                    
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>                                 </nav>
                             </div>
                         </div>
                         
                                                  <div id="crt-head-col3" class="crt-head-col text-right">
                             <button id="crt-sidebar-btn" class="btn btn-icon btn-shade">
                                 <span class="crt-icon crt-icon-side-bar-icon"></span>
                             </button>
                         </div>
                                              </div>
                 </div><!-- .crt-head-inner -->
             </div>

                              <nav id="crt-nav-sm" class="crt-nav hidden-lg hidden-md">
                         <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                 </nav><!-- #crt-nav-sm -->
                     </header><!-- #crt-header -->

        <div id="crt-container" class="crt-container">
            
                            <div id="crt-nav-wrap" class="hidden-sm hidden-xs">
                    <div id="crt-nav-inner">
                        <div class="crt-nav-cont">
                            <div id="crt-nav-scroll">
                                <nav id="crt-nav" class="crt-nav">
                                        <ul class="clear-list">
        <li>
            <a href="index.php" data-tooltip="Home"><img class="avatar avatar-42" src="assets/images/uploads/avatar/avatar-42x42.png" srcset="assets/images/uploads/avatar/avatar-84x84-2x.png 2x" alt=""></a>
        </li>
        <li>
            <a href="experience.php" data-tooltip="Experience"><span class="crt-icon crt-icon-experience"></span></a>
        </li>
        <li>
            <a href="portfolio.php" data-tooltip="Portfolio"><span class="crt-icon crt-icon-portfolio"></span></a>
        </li>
        <li>
            <a href="testimonials.php" data-tooltip="References"><span class="crt-icon crt-icon-references"></span></a>
        </li>
        <li>
            <a href="contact.php" data-tooltip="Contact"><span class="crt-icon crt-icon-contact"></span></a>
        </li>
        <li>
            <a href="category.php" data-tooltip="Blog"><span class="crt-icon crt-icon-blog"></span></a>
        </li>
    </ul>
                                </nav>
                            </div>

                            <div id="crt-nav-tools" class="hidden">
                                <span class="crt-icon crt-icon-dots-three-horizontal"></span>

                                <button id="crt-nav-arrow" class="clear-btn">
                                    <span class="crt-icon crt-icon-chevron-thin-down"></span>
                                </button>
                            </div>
                        </div>
                        <div class="crt-nav-btm"></div>
                    </div>
                </div><!-- .crt-nav-wrap -->
            
            <div class="crt-container-sm"><div class="crt-paper-layers">
    <div class="crt-paper clearfix">
        <div class="crt-paper-cont clear-mrg">

            <article class="post hentry">
                <div class="post-media">
                    <div class="post-vimeo">
                        <iframe src="https://player.vimeo.com/video/195267125" allowfullscreen></iframe>
                    </div>
                </div>

                <div class="padd-box-sm">
                    <header class="post-header text-center">
                        <h1 class="post-title entry-title text-upper">Understanding Colors</h1>

                        <div class="post-header-info">
                            <span class="posted-on"><span class="screen-reader-text">Posted on </span><a
                                    href="http://someurl" rel="bookmark">
                                                                        <time class="post-date published" datetime="2016-07-04T11:33:08+00:00">4 July 2016</time>
                                    <time class="post-date updated" datetime="2016-12-08T14:45:55+00:00">8 December 2016</time>
                                </a></span>
                            &nbsp;<span class="post-author vcard">by <a class="url fn n" href="http://someurl" rel="author">Author</a></span>
                        </div>
                    </header>

                    <div class="post-content entry-content editor clearfix clear-mrg">
                        <p>Your brand is the core of your marketing, the central theme around your products and services.
                            Your brand is not your Logo or your Company Name unless of course you are Microsoft or the
                            Yellow Pages online directory.</p>

                        <p>For people to come and hire you, or buy from you in droves.
                            attractive, exciting and powerful. In fact your brand needs to be powerful enough
                            to rouse your customers into action, and at the same time it needs to actively express you,
                            what you're about and your uniqueness. Once you're sure of your brand you also gain a tangible
                            and easy way of talking to people about what you do. It makes it so much easier to do your marketing
                            when you have it clear in your mind what it is you're selling in the first place. When you're creating
                            your brand you are creating a memorable marketing message that will inspire people to take action and
                            choose you over your competitors.</p>

                        <figure><img src="assets/images/uploads/blog/post-info-img.jpg" alt=""></figure>

                        <h3 class="text-upper">how to set intentions that energize you</h3>

                        <p>Help you find your brand: Your Brand Tip 1 Your brand is the core of what you do.
                            What feelings or emotions does your business inspire in you and in your customers?
                            Did you know that peoples' decision to buy is based on emotions, not facts?
                            Your Brand Tip 2 Think about how you present yourself, not just on your website but
                            when people see you, talk to you on the phone, or read your email. Is your marketing
                            consistently saying what you want it to?</p>

                        <h3 class="text-upper">become a travel pro in one easy lesson</h3>

                        <p>Are people getting confusing messages from you,
                            or is it clear from the start what you do? Your Brand Tip 3 Think like your potential customer,
                            try to get inside their head and see your products or services from their point of view.
                            How do they experience what you do, and how does it make them feel?
                            Your Brand Tip 4 What is it you do that makes you stand out from the crowd? If you don't think you do,
                            then you need to think of a way</p>
                    </div>

                    <footer class="post-footer">
                        <div class="post-footer-top brd-btm">
                            <div class="post-footer-info">
                                <span class="post-cat-links"><span class="screen-reader-text">Categories</span><a
                                        href="http://someurl" rel="category tag">Work</a>&nbsp;,&nbsp;<a
                                        href="http://someurl" rel="category tag">Team</a>
                                </span><span class="post-line">|</span><a
                                    href="" class="post-comments-count">24 comments</a>
                            </div>
                        </div>

                        <div class="post-footer-btm">
                            <div class="post-tags">
                                <span class="screen-reader-text">Tags </span>
                                <a href="http://someurl" title="Nicaragua" rel="tag">Nicaragua</a><a
                                    href="http://someurl" title="Faroe Islands" rel="tag">Faroe Islands</a><a
                                    href="http://someurl" title="American Samoa" rel="tag">American Samoa</a>
                            </div>
                        </div>
                    </footer>
                </div>
            </article><!-- .post -->

            <nav class="post-nav" role="navigation">
                <div class="padd-box-sm brd-btm">
                    <h2 class="screen-reader-text">Post navigation</h2>

                    <div class="row">
                        <div class="col-sm-5 col-xs-6">
                            <div class="post-nav-prev">
                                <a href="http://someurl" rel="prev">
                                    <span class="text-left text-muted">previous article</span>
                                    <figure><img src="assets/images/uploads/blog/prev-post-image.png" alt=""> </figure>
                                    <strong class="text-upper text-center">cook wisely to avoid diabetes</strong>
                                </a>
                            </div>
                        </div>

                        <div class="col-sm-5 col-sm-offset-2 col-xs-6">
                            <div class="post-nav-next">
                                <a href="http://someurl" rel="next">
                                    <span class="text-right text-muted">next article</span>
                                    <figure><img src="assets/images/uploads/blog/next-post-image.png" alt=""></figure>
                                    <strong class="text-upper text-center">what makes a hotel boutique</strong>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav><!-- .post-nav -->

            <div id="comments" class="comments-area">
                <h2 class="title text-upper">Comments</h2>

                <div class="padd-box-sm">
                    <ol class="comment-list clear-list">
                        <li class="comment bypostauthor">
                            <article class="comment-body">
                                <header class="comment-header">
                                    <div class="comment-author vcard">
                                        <img alt="" src="assets/images/uploads/avatar/avatar-58x58-01.png" srcset="assets/images/uploads/avatar/avatar-116x116-01-2x.png 2x" class="avatar avatar-58 photo" height="58" width="58">
                                        <strong class="fn"><a href="https://wordpress.org/" rel="external nofollow" class="url">SOPHIA BALLARD</a></strong>
                                    </div>

                                    <div class="comment-date">
                                        at <a href="#"><time datetime="2016-07-04T11:33:08+00:00">11:58 am October 17.2013</time></a>
                                    </div>
                                </header>

                                <div class="comment-content clear-mrg">
                                    <p>To delete a comment, just log in and view the post's comments. There you will have the option to edit or delete them.</p>
                                </div>

                                <footer class="comment-footer">
                                    <div class="comment-replys-count">
                                        <a rel="nofollow" class="comment-replys-link" href="#" aria-label="Replys to Mr WordPress">3 replies</a>
                                    </div>

                                    <div class="comment-links">
                                        <a class="comment-reply-link" rel="nofollow" href="http://someurl" aria-label="Reply to Mr WordPress">Reply</a>
                                        <a class="comment-edit-link" rel="nofollow" href="http://someurl">Edit</a>
                                    </div>
                                </footer>
                            </article><!-- .comment-body -->

                            <ol class="children clear-list">
                                <li class="comment">
                                    <article class="comment-body">
                                        <header class="comment-header">
                                            <div class="comment-author vcard">
                                                <img alt="" src="assets/images/uploads/avatar/avatar-58x58-default.png" srcset="assets/images/uploads/avatar/avatar-116x116-default-2x.png 2x" class="avatar avatar-58 avatar-default photo" height="58" width="58">
                                                <strong class="fn"><a href="https://wordpress.org/" rel="external nofollow" class="url">STEVE RONALD</a></strong>
                                            </div>

                                            <div class="comment-date">
                                                at <a href="#"><time datetime="2016-07-04T11:33:08+00:00">11:58 am October 17.2013</time></a>
                                            </div>
                                        </header>

                                        <div class="comment-content clear-mrg">
                                            <p>To delete a comment, just log in and view the post's comments. There you will have the option to edit or delete them.</p>
                                        </div>

                                        <footer class="comment-footer">
                                            <div class="comment-links">
                                                <a class="comment-reply-link" rel="nofollow" href="http://someurl" aria-label="Reply to Mr WordPress">Reply</a>
                                            </div>
                                        </footer>
                                    </article><!-- .comment-body -->

                                    <ol class="children clear-list">
                                        <li class="comment bypostauthor">
                                            <article class="comment-body">
                                                <header class="comment-header">
                                                    <div class="comment-author vcard">
                                                        <img alt="" src="assets/images/uploads/avatar/avatar-58x58-01.png" srcset="assets/images/uploads/avatar/avatar-116x116-01-2x.png 2x" class="avatar avatar-58 photo" height="58" width="58">
                                                        <strong class="fn"><a href="https://wordpress.org/" rel="external nofollow" class="url">SOPHIA BALLARD</a></strong>
                                                    </div>

                                                    <div class="comment-date">
                                                        at <a href="#"><time datetime="2016-07-04T11:33:08+00:00">11:58 am October 17.2013</time></a>
                                                    </div>
                                                </header>

                                                <div class="comment-content clear-mrg">
                                                    <p>To delete a comment, just log in and view the post's comments. There you will have the option to edit or delete them.</p>
                                                </div>

                                                <footer class="comment-footer">
                                                    <div class="comment-links">
                                                        <a class="comment-reply-link" rel="nofollow" href="http://someurl" aria-label="Reply to Mr WordPress">Reply</a>
                                                        <a class="comment-edit-link" rel="nofollow" href="http://someurl">Edit</a>
                                                    </div>
                                                </footer>
                                            </article><!-- .comment-body -->
                                        </li><!-- .comment -->
                                    </ol><!-- .children -->
                                </li><!-- .comment -->
                            </ol><!-- .children -->
                        </li><!-- .comment -->

                        <li class="comment">
                            <article class="comment-body">
                                <header class="comment-header">
                                    <div class="comment-author vcard">
                                        <img alt="" src="assets/images/uploads/avatar/avatar-58x58-default.png" srcset="assets/images/uploads/avatar/avatar-116x116-default-2x.jpg 2x" class="avatar avatar-58 avatar-default photo" height="58" width="58">
                                        <strong class="fn"><a href="https://wordpress.org/" rel="external nofollow" class="url">STEVE RONALD</a></strong>
                                    </div>

                                    <div class="comment-date">
                                        at <a href="#"><time datetime="2016-07-04T11:33:08+00:00">11:58 am October 17.2013</time></a>
                                    </div>
                                </header>

                                <div class="comment-content clear-mrg">
                                    <p>To delete a comment, just log in and view the post's comments. There you will have the option to edit or delete them.</p>
                                </div>

                                <footer class="comment-footer">
                                    <div class="comment-links">
                                        <a class="comment-reply-link" rel="nofollow" href="http://someurl" aria-label="Reply to Mr WordPress">Reply</a>
                                    </div>
                                </footer>
                            </article><!-- .comment-body -->
                        </li><!-- .comment -->

                        <li class="comment">
                            <article class="comment-body">
                                <header class="comment-header">
                                    <div class="comment-author vcard">
                                        <img alt="" src="assets/images/uploads/avatar/avatar-58x58-default.png" srcset="assets/images/uploads/avatar/avatar-116x116-default-2x.jpg 2x" class="avatar avatar-58 avatar-default photo" height="58" width="58">
                                        <strong class="fn"><a href="https://wordpress.org/" rel="external nofollow" class="url">TOM BALLARD</a></strong>
                                    </div>

                                    <div class="comment-date">
                                        at <a href="#"><time datetime="2016-07-04T11:33:08+00:00">11:58 am October 17.2013</time></a>
                                    </div>
                                </header>

                                <div class="comment-content clear-mrg">
                                    <p>To delete a comment, just log in and view the post's comments. There you will have the option to edit or delete them.</p>
                                </div>

                                <footer class="comment-footer">
                                    <div class="comment-links">
                                        <a class="comment-reply-link" rel="nofollow" href="http://someurl" aria-label="Reply to Mr WordPress">Reply</a>
                                    </div>
                                </footer>
                            </article><!-- .comment-body -->
                        </li><!-- .comment -->
                    </ol><!-- .comment-list -->
                </div><!-- .padd-box-sm -->
            </div><!-- #comments -->

            <!-- Post Form: Logged In -->
            <div id="respond" class="comment-respond">
                <h2 id="reply-title" class="title text-upper">Leave a Comment</h2>

                <div class="padd-box-sm">
                    <form action="#" method="post" id="commentform" class="comment-form">
                        <p class="logged-in-as">
                            <a href="" aria-label="Logged in as admin. Edit your profile.">Logged in as admin</a>. <a href="">Log
                                out?</a>
                        </p>

                        <div class="form-group">
                            <label class="form-label" for="comment">Your Comment</label>

                            <div class="form-item-wrap">
                                <textarea class="form-item" id="comment" name="comment" cols="45" rows="8" maxlength="65525"
                                          aria-required="true" required="required"></textarea>
                            </div>
                        </div>

                        <div class="form-submit form-item-wrap">
                            <input class="btn btn-primary btn-lg" name="submit" type="submit" value="Post Your Comment">
                        </div>
                    </form>
                </div>
            </div><!-- #respond -->

            <!-- Post Form: Logged Out -->
            <div id="respond2" class="comment-respond">
                <h2 id="reply-title2" class="title text-upper">Leave a Comment
                    <small><a rel="nofollow" id="cancel-comment-reply-link" href="" style="display:none;">Cancel reply</a></small>
                </h2>

                <div class="padd-box-sm">
                    <form action="#" method="post" id="commentform2" class="comment-form" novalidate="">
                        <p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> Required fields
                            are marked <span class="required">*</span></p>

                        <div class="form-group">
                            <label class="form-label" for="comment2">Comment</label>
                            <div class="form-item-wrap">
                                <textarea class="form-item" id="comment2" name="comment" cols="45" rows="8" maxlength="65525" aria-required="true" required="required"></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="author">Name <span class="required">*</span></label>
                            <div class="form-item-wrap">
                                <input class="form-item" id="author" name="author" type="text" value="" size="30" maxlength="245" aria-required="true" required="required">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="email">Email <span class="required">*</span></label>
                            <div class="form-item-wrap">
                                <input class="form-item" id="email" name="email" type="email" value="" size="30" maxlength="100" aria-describedby="email-notes" aria-required="true" required="required">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="url">Website</label>
                            <div class="form-item-wrap">
                                <input class="form-item" id="url" name="url" type="url" value="" size="30" maxlength="200">
                            </div>
                        </div>

                        <div class="form-submit form-item-wrap">
                            <input class="btn btn-primary btn-lg" name="submit" type="submit" value="Post Comment">
                        </div>
                    </form>
                </div>
            </div><!-- #respond -->

        </div>
        <!-- .crt-paper-cont -->
    </div>
    <!-- .crt-paper -->
</div>
<!-- .crt-paper-layers -->
        </div>
        <!-- .crt-container-sm -->
    </div>
    <!-- .crt-container -->

    <div id="crt-sidebar">
    <button id="crt-sidebar-close" class="btn btn-icon btn-light btn-shade">
        <span class="crt-icon crt-icon-close"></span>
    </button>

    <div id="crt-sidebar-inner">
                <nav id="crt-main-nav-sm" class="visible-xs text-center">
            
    <ul class="clear-list">
        <li><a href="index.php">home</a></li>
        <li><a href="portfolio.php">portfolio</a>
        <li class="has-sub-menu"><a href="#">pages</a>
            <ul class="sub-menu">
                <li><a href="typography.php">typography</a></li>
                <li><a href="components.php">components</a></li>
                <li><a href="search.php">search</a></li>
                <li><a href="404.php">404</a></li>
            </ul>
        </li>
        <li class="has-sub-menu"><a href="category.php">blog</a>
            <ul class="sub-menu">
                <li><a href="single.php">single</a></li>
                <li><a href="single-image.php">single image</a></li>
                <li><a href="single-slider.php">single slider</a></li>
                <li><a href="single-youtube.php">single youtube</a></li>
                <li><a href="single-vimeo.php">single vimeo</a></li>
                <li><a href="single-dailymotion.php">single dailymotion</a></li>
                <li><a href="single-soundcloud.php">single soundcloud</a></li>
                <li><a href="single-video.php">single video</a></li>
                <li><a href="single-audio.php">single audio</a></li>
            </ul>
        </li>
        <li><a href="contact.php">contact</a></li>
    </ul>        </nav>
        
        
<div class="crt-card bg-primary text-center">
    <div class="crt-card-avatar">
        <img class="avatar avatar-195" src="assets/images/uploads/avatar/avatar-195x195.png"
             srcset="assets/images/uploads/avatar/avatar-390x390-2x.png 2x" width="195" height="195" alt="">
    </div>
    <div class="crt-card-info">
        <h2 class="text-upper">Ola Lowe</h2>

        <p class="text-muted">Florist | Decorator</p>
        <ul class="crt-social clear-list">
            <li><a><span class="crt-icon crt-icon-facebook"></span></a></li>
            <li><a><span class="crt-icon crt-icon-twitter"></span></a></li>
            <li><a><span class="crt-icon crt-icon-google-plus"></span></a></li>
            <li><a><span class="crt-icon crt-icon-instagram"></span></a></li>
            <li><a><span class="crt-icon crt-icon-pinterest"></span></a></li>
        </ul>
    </div>
</div>
        <aside class="widget-area">
            <section class="widget widget_search">
                <form role="search" method="get" class="search-form" action="#">
                    <label>
                        <span class="screen-reader-text">Search for:</span>
                        <input type="search" class="search-field" placeholder="Search" value="" name="s">
                    </label>
                    <button type="submit" class="search-submit">
                        <span class="screen-reader-text">Search</span>
                        <span class="crt-icon crt-icon-search"></span>
                    </button>
                </form>
            </section>

            <section class="widget widget_posts_entries">
                <h2 class="widget-title">popular posts</h2>
                <ul>
                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-01.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">contextual advertising</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-02.jpg" alt="">
                        </a>
                        <div class="post-content">
                            <h3>
                                <a href="">grilling tips for the dog days of summer</a>
                            </h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>

                    <li>
                        <a class="post-image" href="">
                            <img src="assets/images/uploads/blog/img-70x70-03.png" alt="">
                        </a>
                        <div class="post-content">
                            <h3><a href=""></a>branding do you know who are</h3>
                        </div>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section id="tag_cloud-2" class="widget widget_tag_cloud">
                <h2 class="widget-title">Tags</h2>
                <div class="tagcloud">
                    <a href="" class="tag-link-5 tag-link-position-1" title="1 topic" style="font-size: 1em;">Audios</a>
                    <a href="" class="tag-link-7 tag-link-position-2" title="1 topic" style="font-size: 1em;">Freelance</a></div>
            </section>

            <section id="recent-posts-3" class="widget widget_recent_entries">
                <h4 class="widget-title">Recent Posts</h4>
                <ul>
                    <li>
                        <a href="">Global Travel And Vacations  Luxury Travel On A Tight  Budget</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">cooking for one</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Work</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                    <li>
                        <a href="">An Ugly Myspace Profile Will  Sure Ruin Your Reputation</a>
                        <div class="post-category-comment">
                            <a href="" class="post-category">Photography</a>
                            <a href="" class="post-comments">256 comments</a>
                        </div>
                    </li>
                </ul>
            </section>

            <section class="widget widget_categories">
                <h4 class="widget-title">post categories</h4>
                <ul>
                    <li class="cat-item"><a href="">Audios</a>5</li>
                    <li class="cat-item"><a href="">Daili Inspiration</a>2</li>
                    <li class="cat-item"><a href="">Freelance</a>27</li>
                    <li class="cat-item"><a href="">Links</a>5</li>
                    <li class="cat-item"><a href="">Mobile</a>2</li>
                    <li class="cat-item"><a href="">Phography</a>27</li>
                </ul>
            </section>
        </aside>

    </div><!-- #crt-sidebar-inner -->
</div><!-- #crt-sidebar -->
    <footer id="crt-footer" class="crt-container-lg">
        <div class="crt-container">
            <div class="crt-container-sm clear-mrg text-center">
                <p>Ola Resume @ All Rights Reserved 2016</p>
            </div>
        </div>
        <!-- .crt-container -->
    </footer>
    <!-- #crt-footer -->

        <svg id="crt-bg-shape-1" class="hidden-sm hidden-xs" height="519" width="758">
        <polygon class="pol" points="0,455,693,352,173,0,92,0,0,71"/>
    </svg>

    <svg id="crt-bg-shape-2" class="hidden-sm hidden-xs" height="536" width="633">
        <polygon points="0,0,633,0,633,536"/>
    </svg>
    </div>
<!-- .crt-wrapper -->

<!-- Scripts -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.12.4.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiwY_5J2Bkv2UgSeJa4NOKl6WUezSS9XA"></script>

<script type="text/javascript" src="assets/js/plugins.min.js"></script>
<script type="text/javascript" src="assets/js/theme.min.js"></script>
</body>
</html>